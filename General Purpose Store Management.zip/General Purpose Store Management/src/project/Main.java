
package project;

import mvc.Controller;

/**
 *
 * @author israfil
 */
public class Main {
    public static void main(String[] args) {
        // TODO code application logic here
        
        Controller con = new Controller();
        con.run();

        
    }
}
