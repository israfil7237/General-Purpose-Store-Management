package modelClasses;

import Database.Database;

public class Payment {

    Database database = new Database();

    //Deleting all the data from items table when a new user log in
    public void truncateTable() {
        String query = "Truncate Table items";
        database.removeRecords(query);
    }

    public void getCustomerInfo(String transactionid, String address) {
        String query = "insert into customerDetails(TransactionID, Address)values(?,?)";
        database.storedInfo(query, transactionid, address);

    }
}
