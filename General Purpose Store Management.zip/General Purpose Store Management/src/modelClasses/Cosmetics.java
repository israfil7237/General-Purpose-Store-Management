
package modelClasses;

import Database.Database;

/**
 *
 * @author israfil
 */
public class Cosmetics {
    Database database = new Database();
    //User selected item from Grocery Page
    public void getselectedItem1(int itemNo,int quantity){
       String query = "select name,price from Eyeliner where id ="+itemNo;
        String query1 = "insert into ITEMS(Name,quantity,Price)values(?,?,?)";
        database.getItem(query,query1,quantity);
        
    }
    public void getselectedItem2(int itemNo, int quantity){
        String query = "select name,price from brushes where id ="+itemNo;
        String query1 = "insert into ITEMS(Name,quantity,Price)values(?,?,?)";
        database.getItem(query,query1,quantity);
    }
    public void getselectedItem3(int itemNo, int quantity){
        String query = "select name,price from Nailpolish where id ="+itemNo;
        String query1 = "insert into ITEMS(Name,quantity,Price)values(?,?,?)";
        database.getItem(query,query1,quantity);
    }
    public void getselectedItem4(int itemNo, int quantity){
        String query = "select name,price from Lipstick where id ="+itemNo;
        String query1 = "insert into ITEMS(Name,quantity,Price)values(?,?,?)";
        database.getItem(query,query1,quantity);
    }
}
