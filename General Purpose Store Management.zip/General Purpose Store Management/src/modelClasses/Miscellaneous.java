
package modelClasses;

import Database.Database;

/**
 *
 * @author israfil
 */
public class Miscellaneous {
    Database database = new Database();
    //User selected item from Grocery Page
    public void getselectedItem1(int itemNo,int quantity){
       String query = "select name,price from Books where id ="+itemNo;
        String query1 = "insert into ITEMS(Name,quantity,Price)values(?,?,?)";
        database.getItem(query,query1,quantity);
        
    }
    public void getselectedItem2(int itemNo, int quantity){
        String query = "select name,price from Shampoo where id ="+itemNo;
        String query1 = "insert into ITEMS(Name,quantity,Price)values(?,?,?)";
        database.getItem(query,query1,quantity);
    }
    public void getselectedItem3(int itemNo, int quantity){
        String query = "select name,price from Soap where id ="+itemNo;
        String query1 = "insert into ITEMS(Name,quantity,Price)values(?,?,?)";
        database.getItem(query,query1,quantity);
    }
    public void getselectedItem4(int itemNo, int quantity){
        String query = "select name,price from Lotion where id ="+itemNo;
        String query1 = "insert into ITEMS(Name,quantity,Price)values(?,?,?)";
        database.getItem(query,query1,quantity);
    }
}
