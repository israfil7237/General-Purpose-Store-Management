package modelClasses;

import Database.Database;

/**
 *
 * @author ISRAFIL
 */
public class Inventory {
    Database database = new Database();
    //Making an inventory for customer
    public void MyInventory(){
        String query="select name,quantity,price from items";
        database.getInventory(query);
    }
    public void totalAmount(){
        String query="select sum(price) as total_sum from items";
        database.totalSum(query);
    }
    public void totalDiscount(){
        String query="select sum(price) as total_sum from items";
        database.totalDiscount(query);
    }
}
