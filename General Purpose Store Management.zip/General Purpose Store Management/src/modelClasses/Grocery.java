
package modelClasses;

import Database.Database;

public class Grocery {
    Database database = new Database();

    //User selected item from Grocery Page
    public void getselectedItem1(int itemNo,int quantity){
       String query = "select name,price from Soybeanoil where id ="+itemNo;
        String query1 = "insert into ITEMS(Name,quantity,Price)values(?,?,?)";
        database.getItem(query,query1,quantity);
        
    }
    public void getselectedItem2(int itemNo, int quantity){
        String query = "select name,price from Fish where id ="+itemNo;
        String query1 = "insert into ITEMS(Name,quantity,Price)values(?,?,?)";
        database.getItem(query,query1,quantity);
    }
    public void getselectedItem3(int itemNo, int quantity){
        String query = "select name,price from Meat where id ="+itemNo;
        String query1 = "insert into ITEMS(Name,quantity,Price)values(?,?,?)";
        database.getItem(query,query1,quantity);
    }
    public void getselectedItem4(int itemNo, int quantity){
        String query = "select name,price from Bakery where id ="+itemNo;
        String query1 = "insert into ITEMS(Name,quantity,Price)values(?,?,?)";
        database.getItem(query,query1,quantity);
    }
    
}
