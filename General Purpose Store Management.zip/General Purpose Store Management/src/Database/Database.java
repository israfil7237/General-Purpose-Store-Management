package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Database {

    public static String url = "jdbc:derby://localhost:1527/AssignmentOOP";
    public static String user = "israfil";
    public static String password = "12345";

    Connection myconObj = null;
    Statement mystatObj = null;
    ResultSet myresObj = null;

    public boolean userLoginCheckDB(String email, String pass) {
        boolean chk = false;

//        String query = "Select * from UserInfo Where " + "Email = " + "\'" + email + "\'";
        String query = "Select Email,Password from UserInfo Where Email = " + "\'" + email + "\'" + "AND password =" + "\'" + pass + "\'";
        try {

            myconObj = DriverManager.getConnection(url, user, password);
            mystatObj = myconObj.createStatement();
            myresObj = mystatObj.executeQuery(query);

            if (myresObj.next()) {
                chk = true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return chk;
    }

    public void userSignUpDB(String name, String pass, String email) {
        String query = "insert into UserInfo(Name,Email,Password)values(?,?,?)";

        try {
            myconObj = DriverManager.getConnection(url, user, password);
            PreparedStatement st = myconObj.prepareStatement(query);

            st.setString(1, name);
            st.setString(2, email);
            st.setString(3, pass);
            st.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
//showing the respective product details

    public void showProductsFromDB(String tableName) {

        String query = "Select * from " + tableName;

        try {

            myconObj = DriverManager.getConnection(url, user, password);
            mystatObj = myconObj.createStatement();
            myresObj = mystatObj.executeQuery(query);
            System.out.println("------------------------------------------------");
            while (myresObj.next()) {
                int pk = myresObj.getInt(1);
                String nm = myresObj.getString(2);
                int prc = myresObj.getInt(3);

                System.out.println(pk + ". " + nm + "\t\t" + prc + " tk");
            }
            System.out.println("-------------------------------------------------");

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
//read data from the menu and write it the temporary items table

    public void getItem(String query, String query1, int quantity) {
        try {
            myconObj = DriverManager.getConnection(url, user, password);
            mystatObj = myconObj.createStatement();
            myresObj = mystatObj.executeQuery(query);
            PreparedStatement st = myconObj.prepareStatement(query1);
            while (myresObj.next()) {
                String nm = myresObj.getString(1);
                int prc = myresObj.getInt(2) * quantity;

                st.setString(1, nm);
                st.setInt(2, quantity);
                st.setInt(3, prc);
                st.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Showing order details with individual price and quantity
    public void getInventory(String query) {
        try {
            myconObj = DriverManager.getConnection(url, user, password);
            mystatObj = myconObj.createStatement();
            myresObj = mystatObj.executeQuery(query);
            while (myresObj.next()) {
                String name = myresObj.getString(1);
                int qnty = myresObj.getInt(2);
                int price = myresObj.getInt(3);
                System.out.println(name + "\t\t" + qnty + "\t\t" + price + " tk");

            }
            System.out.println("---------------------------------------------------------");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Sum up all price together and print it
    public void totalSum(String query) {
        try {
            myconObj = DriverManager.getConnection(url, user, password);
            mystatObj = myconObj.createStatement();
            myresObj = mystatObj.executeQuery(query);
            while (myresObj.next()) {
                int price = myresObj.getInt(1);
                System.out.print(price + " tk\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //discount calculation
    public void totalDiscount(String query) {
        try {
            myconObj = DriverManager.getConnection(url, user, password);
            mystatObj = myconObj.createStatement();
            myresObj = mystatObj.executeQuery(query);
            while (myresObj.next()) {
                int price = myresObj.getInt(1);
                if (price >= 1000 && price < 2000) {
                    double discount = (5 * price) / 100;
                    System.out.print("5%\t\t\t\t\t-" + discount + " tk\n");
                    System.out.println("---------------------------------------------------------");
                    System.out.println("Price after Discount\t\t\t\t" + (price - discount) + " tk");
                } else if (price >= 2000 && price < 3000) {
                    double discount = (8 * price) / 100;
                    System.out.print("8%\t\t\t\t\t-" + discount + " tk\n");
                    System.out.println("---------------------------------------------------------");
                    System.out.println("Price after Discount\t\t\t\t" + (price - discount) + " tk");
                } else if (price >= 3000) {
                    double discount = (15 * price) / 100;
                    System.out.print("15%\t\t\t\t\t-" + discount + " tk\n");
                    System.out.println("---------------------------------------------------------");
                    System.out.println("Price after Discount\t\t\t\t" + (price - discount) + " tk");
                } else {
                    System.out.print("\t\t\t\t\t00 tk\n");
                    System.out.println("---------------------------------------------------------");
                    System.out.println("Price after Discount\t\t\t\t" + price + " tk");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //when a new user log in the system all records removing the items table 
    public void removeRecords(String query) {
        try {
            myconObj = DriverManager.getConnection(url, user, password);
            mystatObj = myconObj.createStatement();
            mystatObj.execute(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //customer info stored
    public void storedInfo(String query, String transactionID, String address) {
        try {
            myconObj = DriverManager.getConnection(url, user, password);
            PreparedStatement st = myconObj.prepareStatement(query);

            st.setString(1, transactionID);
            st.setString(2, address);
            st.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

}
