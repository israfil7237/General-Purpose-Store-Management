
package mvc;

import Database.Database;

/**
 *
 * @author israfil
 */
public class Product {
    private String name;
    private int price;

    private Database database = new Database();
    
    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }
    
    
    public void showProducts(String productTable){
        database.showProductsFromDB(productTable);
        
    }

}
