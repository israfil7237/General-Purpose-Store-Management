package mvc;

import java.util.Scanner;

public class View {

    int choice;
    private static Scanner sc = new Scanner(System.in);

    public int firstPage() {
        System.out.println("\t\t****Welcome JGPS****");
        System.out.println("Select anyone from below:");
        System.out.println("1. Login\n"
                + "2. Sign Up\n"
                + "3. Exit");
        System.out.println("Enter your choice: ");
        choice = sc.nextInt();

        return choice;

    }

    public int viewOptions() {
        System.out.println("Select anyone from below:");
        System.out.println("1. Go to categories and select products\n"
                + "2. Order selected products\n"
                + "3. Exit");
        System.out.println("Enter your choice: ");
        choice = sc.nextInt();

        return choice;

    }

    public int showCategories() {
        System.out.println("Select any category ");
        System.out.println("1. Grocery Items\n"
                + "2. Electronics Items\n"
                + "3. Sports Items\n"
                + "4. Cosmetics\n"
                + "5. Miscellaneous\n"
                + "6. Return to previous menu\n");
        System.out.println("Enter your choice: ");
        choice = sc.nextInt();

        return choice;
    }

    public int showGroceryItems() {

        System.out.println("Select any Grocery item:");
        System.out.println("1. Soybean Oil\n"
                + "2. Fish\n"
                + "3. Meat\n"
                + "4. Bakery\n"
                + "5. Return to previous menu\n");
        System.out.println("Enter your choice: ");
        choice = sc.nextInt();

        return choice;
    }
    public int showElectronicsItems() {

        System.out.println("Select any Electronics item:");
        System.out.println("1. Mouse\n"
                + "2. Head phone\n"
                + "3. Key board\n"
                + "4. Router\n"
                + "5. Return to previous menu\n");
        System.out.println("Enter your choice: ");
        choice = sc.nextInt();

        return choice;
    }
    public int showSportsItems() {

        System.out.println("Select any Electronics item:");
        System.out.println("1. Balls\n"
                + "2. Bats\n"
                + "3. Nets\n"
                + "4. Gloves\n"
                + "5. Return to previous menu\n");
        System.out.println("Enter your choice: ");
        choice = sc.nextInt();

        return choice;
    }
    public int showCosmeticsItems() {

        System.out.println("Select any Electronics item:");
        System.out.println("1. Eyeliner\n"
                + "2. brushes\n"
                + "3. nail polish\n"
                + "4. Lipstick\n"
                + "5. Return to previous menu\n");
        System.out.println("Enter your choice: ");
        choice = sc.nextInt();

        return choice;
    }
    public int showMiscellaneousItems() {

        System.out.println("Select any Electronics item:");
        System.out.println("1. Books\n"
                + "2. Shampoo\n"
                + "3. Soap\n"
                + "4. Lotion\n"
                + "5. Return to previous menu\n");
        System.out.println("Enter your choice: ");
        choice = sc.nextInt();

        return choice;
    }

    public void loginSuccessMsg() {
        System.out.println("Login Successful!!!");
    }

    public void loginUnsuccessfulMsg() {
        System.out.println("Login Failed.!!!"
                + "You need to sign up first!!!");
    }

    public void signUpSuccessMsg() {
        System.out.println("Sign up successfull, you can login now!!");
    }

    public void orderMsg() {
        System.out.println("Chose yor product from the menue: ");
    }

    public int getProduct() {
        System.out.println("Enter the item number: ");
        int itemNo = sc.nextInt();
        return itemNo;
    }

    public int getQuantity() {
        System.out.println("Enter the product quantity: ");
        int quantity = sc.nextInt();
        return quantity;
    }
    public void getItemList(){
        System.out.println("Your Item List:\t");
        System.out.println("Item\t\t\t"+"No. of Items\t\t"+"Price");
    }
    public void getAmount(){
        System.out.print("Total price\t\t\t\t\t");
    }
    public void getDiscount(){
        System.out.print("Discount  ");
    }
    public int payment(){
        System.out.println("Press 1 to confirm your order or 0 to deselect items.");
        int confirmation=sc.nextInt();
        return confirmation;
    }
    public int selectPayment(){
        System.out.println("Your order is confirmed. Select anyone payment process:");
        System.out.println("1. bKash (01234102030, Ref: 234)");
        System.out.println("2. Rocket (012341020301)");
        int pay=sc.nextInt();
        sc.nextLine();
        return pay;
    }
    public String getTransactionId(){
        System.out.println("Enter the transaction ID: ");
        String transactionId=sc.nextLine();
        return transactionId;
    }
    public String getAddress(){
        System.out.println("Your payment is confirmed. Enter your address: ");
        String address=sc.nextLine();
        return address;
    }
    public void notification(){
        System.out.println("------------------***********THANK YOU FOR SHOPPING************--------------------------");
        System.out.println("Your product will be delivered soon. Contact this number(01234102030) for delivery updates.\n");
        System.out.println("------------------***********STAY HOME****STAY SAFE************--------------------------");
    }

}
