package mvc;

import modelClasses.Account;
import modelClasses.Cosmetics;
import modelClasses.Electronic;
import modelClasses.Grocery;
import modelClasses.Inventory;
import modelClasses.Miscellaneous;
import modelClasses.Payment;
import modelClasses.Sports;
import modelClasses.User;

/**
 * @author israfil
 */
public class Controller {

    View view = new View();
    User user = new User();
    Account account = new Account();
    Inventory inventory = new Inventory();
    Product product = new Product();
    Grocery grocery = new Grocery();
    Miscellaneous miscellaneous = new Miscellaneous();
    Sports sports = new Sports();
    Electronic electronic = new Electronic();
    Cosmetics cosmetics = new Cosmetics();
    Payment payment = new Payment();

    public void run() {
        int choice = view.firstPage();

        switch (choice) {
            case 1:
                if (account.userLogin() == true) {
                    view.loginSuccessMsg();
                    payment.truncateTable();
                    this.optionPage();
                } else {
                    view.loginUnsuccessfulMsg();
                }
                break;
            case 2:
                user.userSignUp();
                view.signUpSuccessMsg();
                break;
            case 3:
                System.exit(0);
                break;
            default:
                return;
        }
        this.run();
    }

    public void optionPage() {
        int choice = view.viewOptions();

        switch (choice) {
            case 1:
                this.categoryPage();
                break;
            case 2:
                //Print order-list
                view.getItemList();
                inventory.MyInventory();
                //calculating order amount
                view.getAmount();
                inventory.totalAmount();
                //discount calculation
                view.getDiscount();
                inventory.totalDiscount();
                //for payment
                if (view.payment() == 1) {
                    this.paymentPage();
                } else if (view.payment() == 0) {
                    payment.truncateTable();
                    this.optionPage();
                } else {
                    this.categoryPage();
                }
                this.paymentPage();
                break;
            case 3:
                System.exit(0);
                break;
            default:
                return;
        }
        this.optionPage();
    }

    public void categoryPage() {
        int choice = view.showCategories();

        switch (choice) {
            case 1:
                this.groceryPage();
                break;
            case 2:
                this.electronicPage();
                break;
            case 3:
                this.sportsPage();
                break;
            case 4:
                this.cosmeticsPage();
                break;
            case 5:
                this.miscellaneousPage();
                break;
            case 6:
                this.optionPage();
                break;
            default:
                return;
        }
        this.categoryPage();

    }

    public void paymentPage() {
        int choice = view.selectPayment();
        switch (choice) {
            case 1:
                payment.getCustomerInfo(view.getTransactionId(), view.getAddress());
                view.notification();
                break;
            case 2:
                payment.getCustomerInfo(view.getTransactionId(), view.getAddress());
                view.notification();
                break;
            default:
                return;
        }
        this.optionPage();

    }

    //For Grocery item
    public void groceryPage() {
        int choice = view.showGroceryItems();
        switch (choice) {
            case 1:
                product.showProducts("SoybeanOil");
                view.orderMsg();
                grocery.getselectedItem1(view.getProduct(), view.getQuantity());

                break;
            case 2:
                product.showProducts("Fish");
                view.orderMsg();
                grocery.getselectedItem2(view.getProduct(), view.getQuantity());
                break;
            case 3:
                product.showProducts("Meat");
                view.orderMsg();
                grocery.getselectedItem3(view.getProduct(), view.getQuantity());
                break;
            case 4:
                product.showProducts("Bakery");
                view.orderMsg();
                grocery.getselectedItem4(view.getProduct(), view.getQuantity());
                break;
            case 5:
                this.categoryPage();
                break;
            default:
                return;
        }
        this.groceryPage();

    }

    //For electrolnic items
    public void electronicPage() {
        int choice = view.showElectronicsItems();
        switch (choice) {
            case 1:
                product.showProducts("Mouse");
                view.orderMsg();
                electronic.getselectedItem1(view.getProduct(), view.getQuantity());

                break;
            case 2:
                product.showProducts("Headphone");
                view.orderMsg();
                electronic.getselectedItem2(view.getProduct(), view.getQuantity());
                break;
            case 3:
                product.showProducts("Keyboard");
                view.orderMsg();
                electronic.getselectedItem3(view.getProduct(), view.getQuantity());
                break;
            case 4:
                product.showProducts("Router");
                view.orderMsg();
                electronic.getselectedItem4(view.getProduct(), view.getQuantity());
                break;
            case 5:
                this.categoryPage();
                break;
            default:
                return;
        }
        this.electronicPage();

    }

    //For Sports items
    public void sportsPage() {
        int choice = view.showSportsItems();
        switch (choice) {
            case 1:
                product.showProducts("Balls");
                view.orderMsg();
                sports.getselectedItem1(view.getProduct(), view.getQuantity());

                break;
            case 2:
                product.showProducts("Bats");
                view.orderMsg();
                sports.getselectedItem2(view.getProduct(), view.getQuantity());
                break;
            case 3:
                product.showProducts("Nets");
                view.orderMsg();
                sports.getselectedItem3(view.getProduct(), view.getQuantity());
                break;
            case 4:
                product.showProducts("Gloves");
                view.orderMsg();
                sports.getselectedItem4(view.getProduct(), view.getQuantity());
                break;
            case 5:
                this.categoryPage();
                break;
            default:
                return;
        }
        this.sportsPage();

    }

    //For Cosmetic Grocery
    public void cosmeticsPage() {
        int choice = view.showCosmeticsItems();
        switch (choice) {
            case 1:
                product.showProducts("Eyeliner");
                view.orderMsg();
                cosmetics.getselectedItem1(view.getProduct(), view.getQuantity());
                break;
            case 2:
                product.showProducts("brushes");
                view.orderMsg();
                cosmetics.getselectedItem2(view.getProduct(), view.getQuantity());
                break;
            case 3:
                product.showProducts("Nailpolish");
                view.orderMsg();
                cosmetics.getselectedItem3(view.getProduct(), view.getQuantity());
                break;
            case 4:
                product.showProducts("Lipstick");
                view.orderMsg();
                cosmetics.getselectedItem4(view.getProduct(), view.getQuantity());
                break;
            case 5:
                this.categoryPage();
                break;
            default:
                return;
        }
        this.cosmeticsPage();

    }

    //For Miscellaneous Grocery
    public void miscellaneousPage() {
        int choice = view.showMiscellaneousItems();
        switch (choice) {
            case 1:
                product.showProducts("Books");
                view.orderMsg();
                miscellaneous.getselectedItem1(view.getProduct(), view.getQuantity());
                break;
            case 2:
                product.showProducts("Shampoo");
                view.orderMsg();
                miscellaneous.getselectedItem2(view.getProduct(), view.getQuantity());
                break;
            case 3:
                product.showProducts("Soap");
                view.orderMsg();
                miscellaneous.getselectedItem3(view.getProduct(), view.getQuantity());
                break;
            case 4:
                product.showProducts("Lotion");
                view.orderMsg();
                miscellaneous.getselectedItem4(view.getProduct(), view.getQuantity());
                break;
            case 5:
                this.categoryPage();
                break;
            default:
                return;
        }
        this.miscellaneousPage();

    }

}
